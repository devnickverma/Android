package com.example.cropdoc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class activity_login extends AppCompatActivity {

//    private EditText emailInput, passwordInput;
      EditText edEmail, edPassword;
      Button btn;
      TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        edEmail= findViewById(R.id.input_email);
        edPassword = findViewById(R.id.input_password);
        btn = findViewById(R.id.btn_login);
        tv = findViewById(R.id.txt_register);

        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public  void onClick (View view){

                String email = edEmail.getText().toString();
                String password = edPassword.getText().toString();
                if(email.length()==0 || password.length()==0){
                    Toast.makeText(activity_login.this, "please fill all detail",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(activity_login.this, "please fill all detail",Toast.LENGTH_SHORT).show();
                }



            }

        });

        tv.setOnClickListener(new View.OnClickListener(){
             @Override
          public void onClick (View view){
              startActivity(new Intent(  activity_login.this,activity_signup.class));
          }

        });
    }
}
//        // Initialize UI components
//        emailInput = findViewById(R.id.input_email);
//        passwordInput = findViewById(R.id.input_password);
//        Button loginButton = findViewById(R.id.btn_login);
//
//        // Get reference to the register TextView
//        TextView registerText = findViewById(R.id.txt_register);
//
//        // Login button action
//        loginButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String email = emailInput.getText().toString().trim();
//                String password = passwordInput.getText().toString().trim();
//
//                if (email.isEmpty() || password.isEmpty()) {
//                    Toast.makeText(activity_login.this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
//                } else {
//                    // Call your authentication logic here
//                    authenticateUser(email, password);
//                }
//            }
//        });
//
//        // Redirect to registration
//        registerText.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Start Registration Activity
//                startActivity(new Intent(activity_login.this, activity_signup.class));
//            }
//        });
//    }
//
//    private void authenticateUser(String email, String password) {
//        // Add Firebase/Auth or custom API logic here
//        if (email.equals("test@cropdoc.com") && password.equals("password123")) {
//            // Login success, go to home screen
//            startActivity(new Intent(activity_login.this, activity_home.class));
//            finish();
//        } else {
//            // Authentication failed
//            Toast.makeText(activity_login.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//}