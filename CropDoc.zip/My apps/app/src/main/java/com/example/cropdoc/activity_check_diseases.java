package com.example.cropdoc;

import static com.example.cropdoc.R.*;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class activity_check_diseases extends AppCompatActivity {

//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_check_diseases);
//
//        // Initialize UI components
//        ImageView imagePreview = findViewById(R.id.image_preview);
//        Button uploadButton = findViewById(R.id.btn_upload);
//        Button checkDiseaseButton = findViewById(R.id.btn_check_disease);
//
//        // Upload Button Action
//        uploadButton.setOnClickListener(v -> {
//            // Logic to upload an image from the device
//            Toast.makeText(activity_check_diseases.this, "Upload Image", Toast.LENGTH_SHORT).show();
//            startActivity(new Intent(activity_check_diseases.this, activity_upload_images.class));
//        });
//
//        // Check Disease Button Action
//        checkDiseaseButton.setOnClickListener(v -> {
//            // Logic to check for diseases
//            Toast.makeText(activity_check_diseases.this, "Checking for diseases...", Toast.LENGTH_SHORT).show();
//            startActivity(new Intent(activity_check_diseases.this, activity_diseases.class));
//        });
//    }

    private static final int IMAGE_REQUEST_CODE = 100;
    private LinearLayout selectedImagesLayout;
    private ArrayList<String> selectedImagePaths = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button uploadButton = findViewById(R.id.btn_upload);
        Button checkDiseasesButton = findViewById(R.id.btn_check_disease);
        selectedImagesLayout = findViewById(R.id.selected_images_layout);

        // Upload images
        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImagePicker();
            }
        });

        // Check diseases
        checkDiseasesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedImagePaths.isEmpty()) {
                    Toast.makeText(activity_check_diseases.this, "Please upload images first!", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(activity_check_diseases.this, activity_view_reports.class);
                    intent.putStringArrayListExtra("image_paths", selectedImagePaths);
                    startActivity(intent);
                }
            }
        });
    }

    private void openImagePicker() {
        // Here you would open the image picker (gallery or file explorer)
        // For simplicity, let's assume the user selected 5 images
        // and we're adding placeholders to the selectedImagesLayout

        for (int i = 0; i < 5; i++) {
            // Dynamically add ImageView for each selected image
            ImageView imageView = new ImageView(activity_check_diseases.this);
            imageView.setLayoutParams(new LinearLayout.LayoutParams(150, 150));
            imageView.setPadding(8, 8, 8, 8);
            imageView.setImageResource(R.drawable.img1); // Replace with actual image later

            // Add the ImageView to the layout
            selectedImagesLayout.addView(imageView);

            // Simulate image file paths (add actual image file paths in real app)
            selectedImagePaths.add("Image " + (i + 1) + " Path");
        }
    }
}