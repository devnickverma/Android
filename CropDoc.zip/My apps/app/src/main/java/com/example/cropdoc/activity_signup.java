package com.example.cropdoc;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.widget.Toast;
//import androidx.core.view.Insets;


public class activity_signup extends AppCompatActivity {
     EditText edFullName, edEmail,edPassword;
     Button btn;
     TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        edFullName = findViewById(R.id.Textinputfullname);
        edEmail = findViewById(R.id.input_email);
        edPassword = findViewById(R.id.input_password);
        btn = findViewById(R.id.btn_signup);
        tv = findViewById(R.id.txt_login);

        tv.setOnClickListener( new View.OnClickListener(){
            @Override
            public void  onClick(View view){
                startActivity(new Intent(activity_signup.this,activity_login.class));
            }

        });
//        btn.setOnClickListener( new View.OnClickListener(){
//            @Override
//            String fullname =  edFullName.getText().toString();
//            String email = edEmail.getText().toString();
//            String password =  edPassword.getText().toString();
//            if(fullname.length()==0 ||)
//        });
    }
}
//        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_signup);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });
//                // Initialize UI components
//                EditText nameInput = findViewById(R.id.input_name);
//                EditText emailInput = findViewById(R.id.input_email);
//                EditText passwordInput = findViewById(R.id.input_password);
//                Button signupButton = findViewById(R.id.btn_signup);
////
//
//
//                // Sign Up button action
//                signupButton.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
////                        String name = nameInput.getText().toString().trim();
////                        String email = emailInput.getText().toString().trim();
////                        String password = passwordInput.getText().toString().trim();
////
////                        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
////                            Toast.makeText(ActivitySignup.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
////                        } else {
////                            // Call your registration logic here
////                            registerUser(name, email, password);
////                        }
//                        Intent intent = new Intent(activity_signup.this, activity_home.class); // Assuming you have this class
//                        startActivity(intent);
//
//                    }
//                });
//
//
//                // Redirect to Login
//                TextView loginText = findViewById(R.id.txt_login); // Corrected variable declaration
//                loginText.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        Log.d("SignupActivity", "Login Text Clicked"); // Log message for debugging
//                        Intent intent = new Intent(activity_signup.this, activity_login.class); // Assuming you have this class
//                        startActivity(intent);
//                    }
//                });
//
////                loginText.setOnClickListener(new View.OnClickListener() {
////                    @Override
////                    public void onClick(View v) {
////                        Log.d("SignupActivity", "Login Text Clicked");
////                        Intent intent = new Intent(ActivitySignup.this, activity_login.class);
////                        startActivity(intent);
////                    }
////                });
//
////            }
////
////            private void registerUser(String name, String email, String password) {
////                // Add Firebase/Auth or custom API logic here for user registration
////                Toast.makeText(this, "User registered successfully", Toast.LENGTH_SHORT).show();
////                // After registration, redirect to login or home screen
////                startActivity(new Intent(ActivitySignup.this, activity_home.class)); // Assuming you have this class
////                finish();
//
//
//    }
//
//}